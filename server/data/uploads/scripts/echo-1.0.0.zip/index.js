#!/usr/bin/env node
// Echo example: prints TASK_CONFIG.message and exits.
try {
  const cfg = JSON.parse(process.env.TASK_CONFIG || '{}')
  console.log('[echo]', cfg.message ?? '(no message)')
  process.exit(0)
} catch (err) {
  console.error('[echo] failed to parse TASK_CONFIG:', err)
  process.exit(1)
}
