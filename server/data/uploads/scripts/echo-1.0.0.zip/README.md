# Echo 示例脚本

读取 `TASK_CONFIG.message` 并打印到 stdout。
