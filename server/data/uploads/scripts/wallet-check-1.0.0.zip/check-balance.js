#!/usr/bin/env node
// Wallet balance checker - uses ethers.js for RPC calls
try {
  const cfg = JSON.parse(process.env.TASK_CONFIG || '{}')
  console.log("[wallet-check] rpc:", cfg.rpcUrl)
  console.log("[wallet-check] chain:", cfg.chainName)
  console.log("[wallet-check] proxy:", cfg.proxyEnabled ? "on" : "off")
  // Example: load ethers if installed as dependency
  try {
    const { ethers } = require('ethers')
    const provider = new ethers.JsonRpcProvider(cfg.rpcUrl || 'https://eth.llamarpc.com')
    console.log("[wallet-check] ethers loaded, blockNumber:", await provider.getBlockNumber())
  } catch (e) {
    console.log("[wallet-check] ethers not available, skipping RPC check")
  }
  process.exit(0)
} catch (err) {
  console.error('[wallet-check] error:', err)
  process.exit(1)
}
